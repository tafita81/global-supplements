# Global Supplements

Plataforma global de suplementos premium conectando governos, empresas e consumidores através de tecnologia avançada.

## Tecnologias

- React 18
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui

## Desenvolvimento Local

```bash
npm install
npm run dev
```

## Build para Produção

```bash
npm run build
```

Os arquivos de produção estarão na pasta `dist/`

## Global Supplements © 2024

Todos os direitos reservados.
